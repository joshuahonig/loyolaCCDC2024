
from fail2ban.server.action import ActionBase


class TestAction(ActionBase):
    pass
